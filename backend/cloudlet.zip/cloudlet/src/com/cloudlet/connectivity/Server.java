package com.cloudlet.connectivity;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class Server implements ConnectionChangeListener{
	private int START = 0;
	private int STOP = 1;
	
	private int running = 0;
	private HashMap<String, ConnectionHandler> connectedUsers = new HashMap<String, ConnectionHandler>();
	
	public void run() throws IOException{
		ServerSocket sSocket = new ServerSocket(9090);
		while(running == START){
			System.err.println("waiting for connection...");
			Socket s = sSocket.accept();
			ConnectionHandler handler = new ConnectionHandler(s);
			handler.addListener(this);
			connectionchange(ConnectionChangeListener.CONNECTED,  handler, s.getInetAddress().toString());
			System.err.println("connection accepted...");
		}
	}
	
	public void start() throws IOException{
		running = START;
		run();
	}
	public void stop(){
		running = STOP;
	}
	
	public void connectionchange(int status, ConnectionHandler handler, String ip) {
		if (ConnectionChangeListener.CONNECTED == status){
			connectedUsers.put(ip, handler);
		}else if (ConnectionChangeListener.DISCONNECTED == status){
			connectedUsers.remove(ip);
		}
	}
}